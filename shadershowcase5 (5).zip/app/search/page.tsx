"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Search, Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ShaderBackground from "@/components/shader-background"
import PulsingCircle from "@/components/pulsing-circle"
import { products, categories } from "@/lib/products"

export default function SearchPage() {
  const searchParams = useSearchParams()
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "")
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get("category") || "all")
  const [priceRange, setPriceRange] = useState({ min: 0, max: 5000 })
  const [sortBy, setSortBy] = useState(searchParams.get("sort") || "name")
  const [filteredProducts, setFilteredProducts] = useState(products)
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    let filtered = products

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.category.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Filter by category
    if (selectedCategory !== "all") {
      if (selectedCategory === "new") {
        filtered = filtered.filter((product) => product.label === "NEW")
      } else {
        filtered = filtered.filter((product) => product.category.toLowerCase() === selectedCategory.toLowerCase())
      }
    }

    // Filter by price range
    filtered = filtered.filter((product) => product.price >= priceRange.min && product.price <= priceRange.max)

    // Sort products
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.rating - a.rating
        case "name":
        default:
          return a.name.localeCompare(b.name)
      }
    })

    setFilteredProducts(filtered)
  }, [searchQuery, selectedCategory, priceRange, sortBy])

  const clearFilters = () => {
    setSearchQuery("")
    setSelectedCategory("all")
    setPriceRange({ min: 0, max: 5000 })
    setSortBy("name")
  }

  return (
    <ShaderBackground>
      <Header />
      <div className="min-h-screen pt-20">
        <div className="container mx-auto px-4 lg:px-6">
          {/* Back Button */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 p-0">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </motion.div>

          {/* Search Header */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-6">Search Products</h1>

            {/* Search Bar */}
            <div className="relative max-w-2xl">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/60" />
              <Input
                type="text"
                placeholder="Search for furniture, categories, or features..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white"
              />
            </div>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Filters Sidebar */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-1">
              {/* Mobile Filter Toggle */}
              <div className="lg:hidden mb-4">
                <Button
                  onClick={() => setShowFilters(!showFilters)}
                  variant="outline"
                  className="w-full border-white text-white hover:bg-white hover:text-black"
                >
                  <Filter className="w-4 h-4 mr-2" />
                  {showFilters ? "Hide Filters" : "Show Filters"}
                </Button>
              </div>

              <div
                className={`bg-white/5 backdrop-blur-md border border-white/10 rounded-lg p-6 ${showFilters ? "block" : "hidden lg:block"}`}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-white">Filters</h2>
                  <Button
                    onClick={clearFilters}
                    variant="ghost"
                    size="sm"
                    className="text-white/60 hover:text-white hover:bg-white/10"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Clear
                  </Button>
                </div>

                {/* Category Filter */}
                <div className="mb-6">
                  <h3 className="text-white font-medium mb-3">Category</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <label
                        key={category.id}
                        className="flex items-center text-white/80 hover:text-white cursor-pointer"
                      >
                        <input
                          type="radio"
                          name="category"
                          value={category.id}
                          checked={selectedCategory === category.id}
                          onChange={(e) => setSelectedCategory(e.target.value)}
                          className="mr-3 text-white"
                        />
                        {category.name} ({category.count})
                      </label>
                    ))}
                  </div>
                </div>

                {/* Price Range Filter */}
                <div className="mb-6">
                  <h3 className="text-white font-medium mb-3">Price Range</h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        type="number"
                        placeholder="Min"
                        value={priceRange.min}
                        onChange={(e) => setPriceRange({ ...priceRange, min: Number.parseInt(e.target.value) || 0 })}
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white"
                      />
                      <Input
                        type="number"
                        placeholder="Max"
                        value={priceRange.max}
                        onChange={(e) => setPriceRange({ ...priceRange, max: Number.parseInt(e.target.value) || 5000 })}
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white"
                      />
                    </div>
                    <div className="flex justify-between text-white/60 text-sm">
                      <span>${priceRange.min}</span>
                      <span>${priceRange.max}</span>
                    </div>
                  </div>
                </div>

                {/* Sort By */}
                <div>
                  <h3 className="text-white font-medium mb-3">Sort By</h3>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full bg-white/10 border border-white/20 text-white rounded-md px-3 py-2 focus:border-white focus:outline-none"
                  >
                    <option value="name">Name (A-Z)</option>
                    <option value="price-low">Price (Low to High)</option>
                    <option value="price-high">Price (High to Low)</option>
                    <option value="rating">Highest Rated</option>
                  </select>
                </div>
              </div>
            </motion.div>

            {/* Results */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-3"
            >
              {/* Results Header */}
              <div className="flex justify-between items-center mb-6">
                <p className="text-white/80">
                  {filteredProducts.length} {filteredProducts.length === 1 ? "result" : "results"}
                  {searchQuery && ` for "${searchQuery}"`}
                </p>
              </div>

              {/* Products Grid */}
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredProducts.map((product, index) => (
                    <motion.div
                      key={product.id}
                      className="relative group cursor-pointer"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: index * 0.1 }}
                      whileHover={{ y: -5 }}
                    >
                      <Link href={`/product/${product.id}`}>
                        <div className="relative aspect-square rounded-lg overflow-hidden">
                          <Image
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            fill
                            className="object-cover transition-transform duration-500 group-hover:scale-105"
                          />

                          {/* Product Label */}
                          {product.label && (
                            <div
                              className={`absolute ${
                                product.labelPosition === "top-left"
                                  ? "top-4 left-4"
                                  : product.labelPosition === "top-right"
                                    ? "top-4 right-4"
                                    : product.labelPosition === "bottom-left"
                                      ? "bottom-4 left-4"
                                      : "bottom-4 right-4"
                              } backdrop-blur-md bg-white/10 border border-white/20 rounded-lg px-3 py-1`}
                            >
                              <p className="text-white text-xs font-medium tracking-wide">{product.label}</p>
                            </div>
                          )}

                          {/* Hover Overlay */}
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </div>

                        {/* Product Info */}
                        <div className="mt-4 text-white">
                          <h3 className="text-lg font-medium tracking-tight">{product.name}</h3>
                          <p className="text-white/60 text-sm mb-1">{product.category}</p>
                          <div className="flex items-center gap-2">
                            <p className="text-white font-semibold">${product.price}</p>
                            {product.originalPrice > product.price && (
                              <p className="text-white/50 text-sm line-through">${product.originalPrice}</p>
                            )}
                          </div>
                          <div className="flex items-center mt-1">
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <div
                                  key={i}
                                  className={`w-3 h-3 rounded-full mr-1 ${
                                    i < Math.floor(product.rating) ? "bg-yellow-400" : "bg-white/20"
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-white/60 text-xs ml-2">({product.reviews})</span>
                          </div>
                        </div>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center text-white py-16"
                >
                  <Search className="w-16 h-16 text-white/30 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No products found</h3>
                  <p className="text-white/60 mb-6">Try adjusting your search or filters</p>
                  <Button onClick={clearFilters} className="bg-white text-black hover:bg-white/90">
                    Clear Filters
                  </Button>
                </motion.div>
              )}
            </motion.div>
          </div>
        </div>
        <Footer />
      </div>
      <PulsingCircle />
    </ShaderBackground>
  )
}
