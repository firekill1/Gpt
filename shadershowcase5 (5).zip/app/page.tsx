"use client"

import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import ProductGrid from "@/components/product-grid"
import Sidebar from "@/components/sidebar"
import Footer from "@/components/footer"
import PulsingCircle from "@/components/pulsing-circle"
import ShaderBackground from "@/components/shader-background"

export default function EcommerceHome() {
  return (
    <ShaderBackground>
      <Header />
      <div className="min-h-screen">
        <div className="container mx-auto px-4 lg:px-6 pt-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
            {/* Sidebar - Hidden on mobile, 4 columns on desktop */}
            <div className="hidden lg:block lg:col-span-4">
              <Sidebar />
            </div>

            {/* Main Content - Full width on mobile, 8 columns on desktop */}
            <div className="lg:col-span-8">
              <HeroSection />
              <ProductGrid />
            </div>
          </div>
        </div>
        <Footer />
      </div>
      <PulsingCircle />
    </ShaderBackground>
  )
}
