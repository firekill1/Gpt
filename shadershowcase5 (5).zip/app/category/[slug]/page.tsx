"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ShaderBackground from "@/components/shader-background"
import PulsingCircle from "@/components/pulsing-circle"
import { products, categories } from "@/lib/products"

interface CategoryPageProps {
  params: Promise<{ slug: string }>
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = await params

  // Find the category
  const category = categories.find((cat) => cat.id === slug)

  // Filter products by category
  const filteredProducts =
    slug === "all" ? products : products.filter((product) => product.category.toLowerCase() === slug.toLowerCase())

  // Special handling for "new" category - show products with "NEW" label
  const displayProducts = slug === "new" ? products.filter((product) => product.label === "NEW") : filteredProducts

  const categoryTitle = category?.name || slug.charAt(0).toUpperCase() + slug.slice(1)

  return (
    <ShaderBackground>
      <Header />
      <div className="min-h-screen pt-20">
        <div className="container mx-auto px-4 lg:px-6">
          {/* Back Button */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 p-0">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </motion.div>

          {/* Category Header */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12 text-center">
            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-4 text-balance">{categoryTitle}</h1>
            <p className="text-white/80 text-lg">
              {displayProducts.length} {displayProducts.length === 1 ? "product" : "products"} available
            </p>
          </motion.div>

          {/* Products Grid */}
          {displayProducts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
              {displayProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  className="relative group cursor-pointer"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                >
                  <Link href={`/product/${product.id}`}>
                    <div className="relative aspect-square rounded-lg overflow-hidden">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                      />

                      {/* Product Label */}
                      {product.label && (
                        <div
                          className={`absolute ${
                            product.labelPosition === "top-left"
                              ? "top-4 left-4"
                              : product.labelPosition === "top-right"
                                ? "top-4 right-4"
                                : product.labelPosition === "bottom-left"
                                  ? "bottom-4 left-4"
                                  : "bottom-4 right-4"
                          } backdrop-blur-md bg-white/10 border border-white/20 rounded-lg px-3 py-1`}
                        >
                          <p className="text-white text-xs font-medium tracking-wide">{product.label}</p>
                        </div>
                      )}

                      {/* Hover Overlay */}
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </div>

                    {/* Product Info */}
                    <div className="mt-4 text-white">
                      <h3 className="text-lg font-medium tracking-tight">{product.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-white font-semibold">${product.price}</p>
                        {product.originalPrice > product.price && (
                          <p className="text-white/50 text-sm line-through">${product.originalPrice}</p>
                        )}
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center text-white py-16"
            >
              <h2 className="text-2xl font-bold mb-4">No Products Found</h2>
              <p className="text-white/80 mb-8">We couldn't find any products in this category.</p>
              <Link href="/">
                <Button className="bg-white text-black hover:bg-white/90">Browse All Products</Button>
              </Link>
            </motion.div>
          )}

          {/* Category Navigation */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-16"
          >
            <div className="flex flex-wrap justify-center gap-4">
              {categories.map((cat) => (
                <Link key={cat.id} href={`/category/${cat.id}`}>
                  <Button
                    variant={slug === cat.id ? "default" : "outline"}
                    className={
                      slug === cat.id
                        ? "bg-white text-black hover:bg-white/90"
                        : "border-white text-white hover:bg-white hover:text-black"
                    }
                  >
                    {cat.name} ({cat.count})
                  </Button>
                </Link>
              ))}
            </div>
          </motion.div>
        </div>
        <Footer />
      </div>
      <PulsingCircle />
    </ShaderBackground>
  )
}
