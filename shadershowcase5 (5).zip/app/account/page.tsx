"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, User, Package, Heart, Settings, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ShaderBackground from "@/components/shader-background"
import PulsingCircle from "@/components/pulsing-circle"

const mockUser = {
  firstName: "John",
  lastName: "Doe",
  email: "john.doe@example.com",
  joinDate: "March 2024",
}

const mockOrders = [
  {
    id: "ORD-001",
    date: "2024-03-15",
    status: "Delivered",
    total: 899,
    items: ["Minimal Chair"],
  },
  {
    id: "ORD-002",
    date: "2024-03-10",
    status: "Shipped",
    total: 1299,
    items: ["Elegant Table"],
  },
  {
    id: "ORD-003",
    date: "2024-03-05",
    status: "Processing",
    total: 2648,
    items: ["Refined Sofa", "Statement Lamp"],
  },
]

export default function AccountPage() {
  const [activeTab, setActiveTab] = useState("profile")
  const [formData, setFormData] = useState({
    firstName: mockUser.firstName,
    lastName: mockUser.lastName,
    email: mockUser.email,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Profile update:", formData)
  }

  const tabs = [
    { id: "profile", label: "Profile", icon: User },
    { id: "orders", label: "Orders", icon: Package },
    { id: "wishlist", label: "Wishlist", icon: Heart },
    { id: "settings", label: "Settings", icon: Settings },
  ]

  return (
    <ShaderBackground>
      <Header />
      <div className="min-h-screen pt-20">
        <div className="container mx-auto px-4 lg:px-6">
          {/* Back Button */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 p-0">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-1">
              <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-lg p-6">
                <div className="text-center mb-6">
                  <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-white font-semibold">
                    {mockUser.firstName} {mockUser.lastName}
                  </h2>
                  <p className="text-white/60 text-sm">Member since {mockUser.joinDate}</p>
                </div>

                <nav className="space-y-2">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === tab.id
                          ? "bg-white text-black"
                          : "text-white/80 hover:bg-white/10 hover:text-white"
                      }`}
                    >
                      <tab.icon className="w-4 h-4" />
                      {tab.label}
                    </button>
                  ))}
                  <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left text-red-400 hover:bg-red-400/10 transition-colors">
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </nav>
              </div>
            </motion.div>

            {/* Main Content */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-3"
            >
              <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-lg p-8">
                {activeTab === "profile" && (
                  <div>
                    <h1 className="text-2xl font-bold text-white mb-6">Profile Information</h1>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="firstName" className="text-white mb-2 block">
                            First Name
                          </Label>
                          <Input
                            id="firstName"
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleChange}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white"
                          />
                        </div>
                        <div>
                          <Label htmlFor="lastName" className="text-white mb-2 block">
                            Last Name
                          </Label>
                          <Input
                            id="lastName"
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleChange}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="email" className="text-white mb-2 block">
                          Email Address
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-white"
                        />
                      </div>
                      <Button type="submit" className="bg-white text-black hover:bg-white/90">
                        Update Profile
                      </Button>
                    </form>
                  </div>
                )}

                {activeTab === "orders" && (
                  <div>
                    <h1 className="text-2xl font-bold text-white mb-6">Order History</h1>
                    <div className="space-y-4">
                      {mockOrders.map((order) => (
                        <div
                          key={order.id}
                          className="bg-white/5 border border-white/10 rounded-lg p-6 hover:bg-white/10 transition-colors"
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h3 className="text-white font-semibold">Order {order.id}</h3>
                              <p className="text-white/60 text-sm">{order.date}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-white font-semibold">${order.total}</p>
                              <span
                                className={`text-xs px-2 py-1 rounded ${
                                  order.status === "Delivered"
                                    ? "bg-green-500/20 text-green-400"
                                    : order.status === "Shipped"
                                      ? "bg-blue-500/20 text-blue-400"
                                      : "bg-yellow-500/20 text-yellow-400"
                                }`}
                              >
                                {order.status}
                              </span>
                            </div>
                          </div>
                          <div>
                            <p className="text-white/80 text-sm">Items: {order.items.join(", ")}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === "wishlist" && (
                  <div>
                    <h1 className="text-2xl font-bold text-white mb-6">Wishlist</h1>
                    <div className="text-center py-12">
                      <Heart className="w-16 h-16 text-white/30 mx-auto mb-4" />
                      <h3 className="text-white text-lg mb-2">Your wishlist is empty</h3>
                      <p className="text-white/60 mb-6">Save items you love for later</p>
                      <Link href="/">
                        <Button className="bg-white text-black hover:bg-white/90">Browse Products</Button>
                      </Link>
                    </div>
                  </div>
                )}

                {activeTab === "settings" && (
                  <div>
                    <h1 className="text-2xl font-bold text-white mb-6">Account Settings</h1>
                    <div className="space-y-6">
                      <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                        <h3 className="text-white font-semibold mb-4">Email Preferences</h3>
                        <div className="space-y-3">
                          <label className="flex items-center text-white/80">
                            <input type="checkbox" defaultChecked className="mr-3 rounded border-white/20" />
                            Product updates and new arrivals
                          </label>
                          <label className="flex items-center text-white/80">
                            <input type="checkbox" defaultChecked className="mr-3 rounded border-white/20" />
                            Order updates and shipping notifications
                          </label>
                          <label className="flex items-center text-white/80">
                            <input type="checkbox" className="mr-3 rounded border-white/20" />
                            Marketing and promotional emails
                          </label>
                        </div>
                      </div>

                      <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                        <h3 className="text-white font-semibold mb-4">Privacy Settings</h3>
                        <div className="space-y-3">
                          <label className="flex items-center text-white/80">
                            <input type="checkbox" defaultChecked className="mr-3 rounded border-white/20" />
                            Allow personalized recommendations
                          </label>
                          <label className="flex items-center text-white/80">
                            <input type="checkbox" className="mr-3 rounded border-white/20" />
                            Share data for analytics
                          </label>
                        </div>
                      </div>

                      <Button className="bg-white text-black hover:bg-white/90">Save Settings</Button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
        <Footer />
      </div>
      <PulsingCircle />
    </ShaderBackground>
  )
}
