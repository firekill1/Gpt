"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ShaderBackground from "@/components/shader-background"
import PulsingCircle from "@/components/pulsing-circle"
import { useCart } from "@/contexts/cart-context"

export default function CartPage() {
  const { state, dispatch } = useCart()

  const updateQuantity = (id: number, quantity: number) => {
    dispatch({ type: "UPDATE_QUANTITY", payload: { id, quantity } })
  }

  const removeItem = (id: number) => {
    dispatch({ type: "REMOVE_ITEM", payload: id })
  }

  if (state.items.length === 0) {
    return (
      <ShaderBackground>
        <Header />
        <div className="min-h-screen pt-20">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center text-white py-16">
              <h1 className="text-4xl font-bold mb-4">Your Cart is Empty</h1>
              <p className="text-white/80 mb-8">Discover our beautiful collection of modern furniture</p>
              <Link href="/">
                <Button className="bg-white text-black hover:bg-white/90">Continue Shopping</Button>
              </Link>
            </div>
          </div>
          <Footer />
        </div>
        <PulsingCircle />
      </ShaderBackground>
    )
  }

  return (
    <ShaderBackground>
      <Header />
      <div className="min-h-screen pt-20">
        <div className="container mx-auto px-4 lg:px-6">
          {/* Back Button */}
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 p-0">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Continue Shopping
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-white mb-6">Shopping Cart</h1>
                <p className="text-white/80">
                  {state.itemCount} {state.itemCount === 1 ? "item" : "items"} in your cart
                </p>
              </div>

              <div className="space-y-6">
                {state.items.map((item, index) => (
                  <div key={item.id} className="bg-white/5 backdrop-blur-md border border-white/10 rounded-lg p-6">
                    <div className="flex gap-4">
                      <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          width={96}
                          height={96}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="text-white font-semibold">{item.name}</h3>
                            <p className="text-white/60 text-sm">{item.category}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(item.id)}
                            className="text-white/60 hover:text-red-400 hover:bg-red-400/10"
                          >
                            ✕
                          </Button>
                        </div>

                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="w-8 h-8 p-0 border-white/20 text-white hover:bg-white hover:text-black"
                            >
                              −
                            </Button>
                            <span className="text-white font-medium w-8 text-center">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="w-8 h-8 p-0 border-white/20 text-white hover:bg-white hover:text-black"
                            >
                              +
                            </Button>
                          </div>

                          <div className="text-right">
                            <p className="text-white font-semibold">${item.price * item.quantity}</p>
                            <p className="text-white/60 text-sm">${item.price} each</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-lg p-6 sticky top-24">
                <h2 className="text-xl font-semibold text-white mb-6">Order Summary</h2>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-white/80">
                    <span>Subtotal</span>
                    <span>${state.total}</span>
                  </div>
                  <div className="flex justify-between text-white/80">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between text-white/80">
                    <span>Tax</span>
                    <span>${Math.round(state.total * 0.08)}</span>
                  </div>
                  <div className="border-t border-white/10 pt-3">
                    <div className="flex justify-between text-white font-semibold text-lg">
                      <span>Total</span>
                      <span>${state.total + Math.round(state.total * 0.08)}</span>
                    </div>
                  </div>
                </div>

                <Link href="/checkout">
                  <Button className="w-full bg-white text-black hover:bg-white/90 mb-4">Proceed to Checkout</Button>
                </Link>

                <p className="text-white/60 text-xs text-center">Free shipping on orders over $500</p>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
      <PulsingCircle />
    </ShaderBackground>
  )
}
