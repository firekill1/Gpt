"use client"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ShaderBackground from "@/components/shader-background"
import PulsingCircle from "@/components/pulsing-circle"
import Link from "next/link"
import { products } from "@/lib/products"
import ProductClient from "./product-client"

interface ProductPageProps {
  params: Promise<{ id: string }>
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { id } = await params
  const product = products.find((p) => p.id === Number.parseInt(id))

  if (!product) {
    return (
      <ShaderBackground>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
            <Link href="/">
              <Button
                variant="outline"
                className="text-white border-white hover:bg-white hover:text-black bg-transparent"
              >
                Return Home
              </Button>
            </Link>
          </div>
        </div>
        <PulsingCircle />
      </ShaderBackground>
    )
  }

  return (
    <ShaderBackground>
      <Header />
      <div className="min-h-screen pt-20">
        <div className="container mx-auto px-4 lg:px-6">
          {/* Back Button */}
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 p-0">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Products
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            {/* Product Images */}
            <div>
              <div className="aspect-square rounded-lg overflow-hidden mb-4">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={600}
                  height={600}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {product.images.map((img, index) => (
                  <div
                    key={index}
                    className="aspect-square rounded-lg overflow-hidden cursor-pointer opacity-70 hover:opacity-100 transition-opacity"
                  >
                    <Image
                      src={img || "/placeholder.svg"}
                      alt={`${product.name} view ${index + 1}`}
                      width={150}
                      height={150}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div className="text-white">
              <div className="mb-4">
                <p className="text-white/60 text-sm mb-2">{product.category}</p>
                <h1 className="text-4xl font-bold mb-4 text-balance">{product.name}</h1>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-6">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className={`w-4 h-4 mr-1 ${i < Math.floor(product.rating) ? "text-yellow-400" : "text-white/30"}`}
                      >
                        ★
                      </div>
                    ))}
                  </div>
                  <span className="text-sm text-white/80">
                    {product.rating} ({product.reviews} reviews)
                  </span>
                </div>
              </div>

              {/* Price */}
              <div className="mb-6">
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-bold">${product.price}</span>
                  <span className="text-lg text-white/50 line-through">${product.originalPrice}</span>
                  <span className="bg-red-500 text-white text-xs px-2 py-1 rounded">
                    SAVE ${product.originalPrice - product.price}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-white/80 mb-6 leading-relaxed text-pretty">{product.description}</p>

              {/* Features */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-3">Features</h3>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-white/80">
                      <div className="w-1.5 h-1.5 bg-white rounded-full mr-3" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <ProductClient product={product} />

              {/* Stock Status */}
              <div className="mt-4">
                <p className="text-sm text-green-400">✓ In Stock - Ships within 2-3 business days</p>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
      <PulsingCircle />
    </ShaderBackground>
  )
}
