"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Award, Leaf, Users, Truck } from "lucide-react"
import { Button } from "@/components/ui/button"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ShaderBackground from "@/components/shader-background"
import PulsingCircle from "@/components/pulsing-circle"

const values = [
  {
    icon: Leaf,
    title: "Sustainable Design",
    description:
      "Every piece is crafted with environmental responsibility in mind, using sustainable materials and ethical production methods.",
  },
  {
    icon: Award,
    title: "Premium Quality",
    description:
      "We source only the finest materials and work with master craftspeople to ensure each piece meets our exacting standards.",
  },
  {
    icon: Users,
    title: "Human-Centered",
    description:
      "Our designs prioritize comfort and functionality, creating furniture that enhances daily life and brings people together.",
  },
  {
    icon: Truck,
    title: "Global Delivery",
    description:
      "We deliver our carefully packaged furniture worldwide, ensuring your pieces arrive in perfect condition.",
  },
]

export default function AboutPage() {
  return (
    <ShaderBackground>
      <Header />
      <div className="min-h-screen pt-20">
        <div className="container mx-auto px-4 lg:px-6">
          {/* Back Button */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 p-0">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </motion.div>

          {/* Hero Section */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6 text-balance">
              Refined. Minimal. Never boring.
            </h1>
            <p className="text-white/80 text-lg lg:text-xl max-w-3xl mx-auto leading-relaxed text-pretty">
              We believe that great design should be accessible, sustainable, and timeless. Our curated collection
              brings together the finest examples of modern minimalist furniture, each piece carefully selected for its
              exceptional quality and enduring appeal.
            </p>
          </motion.div>

          {/* Story Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
              <div className="aspect-square rounded-lg overflow-hidden">
                <Image
                  src="/modern-minimalist-furniture-workshop-with-craftspe.jpg"
                  alt="Our craftspeople at work"
                  width={600}
                  height={600}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col justify-center text-white"
            >
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-white/80 leading-relaxed">
                <p>
                  Founded in 2018, we started with a simple mission: to make exceptional design accessible to everyone.
                  What began as a small collection of carefully curated pieces has grown into a global community of
                  design enthusiasts who share our passion for quality and sustainability.
                </p>
                <p>
                  We work directly with independent designers and small manufacturers around the world, ensuring fair
                  wages and sustainable practices while bringing you furniture that tells a story.
                </p>
                <p>
                  Every piece in our collection is chosen not just for its beauty, but for its ability to enhance daily
                  life and stand the test of time.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Values Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mb-16"
          >
            <h2 className="text-3xl font-bold text-white text-center mb-12">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 mx-auto mb-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center">
                    <value.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-white font-semibold mb-2">{value.title}</h3>
                  <p className="text-white/70 text-sm leading-relaxed">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* CTA Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white mb-6">Ready to Transform Your Space?</h2>
            <p className="text-white/80 mb-8 max-w-2xl mx-auto">
              Discover our carefully curated collection of modern furniture designed to elevate your everyday living.
            </p>
            <Link href="/">
              <Button className="bg-white text-black hover:bg-white/90 px-8 py-3">Shop Collection</Button>
            </Link>
          </motion.div>
        </div>
        <Footer />
      </div>
      <PulsingCircle />
    </ShaderBackground>
  )
}
