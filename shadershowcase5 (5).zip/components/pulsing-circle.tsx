"use client"

export default function PulsingCircle() {
  return (
    <div className="absolute bottom-8 right-8 z-30">
      <div className="relative w-20 h-20 flex items-center justify-center">
        <div className="w-16 h-16 rounded-full border-2 border-white/30 animate-pulse" />

        <div className="absolute inset-0 w-full h-full animate-spin" style={{ animationDuration: "20s" }}>
          <svg className="w-full h-full" viewBox="0 0 100 100" style={{ transform: "scale(1.6)" }}>
            <defs>
              <path id="circle" d="M 50, 50 m -38, 0 a 38,38 0 1,1 76,0 a 38,38 0 1,1 -76,0" />
            </defs>
            <text className="text-sm fill-white/80 instrument">
              <textPath href="#circle" startOffset="0%">
                v0 is amazing • v0 is amazing • v0 is amazing • v0 is amazing •
              </textPath>
            </text>
          </svg>
        </div>
      </div>
    </div>
  )
}
