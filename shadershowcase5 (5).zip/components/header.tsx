"use client"

import { useState } from "react"
import CartIcon from "@/components/cart-icon"
import SearchBar from "@/components/search-bar"
import Link from "next/link"

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [showSearch, setShowSearch] = useState(false)

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-black/20 border-b border-white/10">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Mobile Menu Button */}
            <button className="lg:hidden text-white p-2" onClick={() => setIsMobileMenuOpen(true)}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>

            {/* Updated Logo */}
            <Link href="/" className="flex items-center">
              <div className="text-white font-light text-xl tracking-wide">
                <span className="font-normal">Lumeo</span>
                <span className="text-white/80">Shop</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center backdrop-blur-md bg-white/5 border border-white/10 rounded-full px-6 py-2">
              <Link
                href="/category/new"
                className="text-white/80 hover:text-white text-xs font-medium px-4 py-2 transition-colors duration-200 uppercase tracking-wide"
              >
                New
              </Link>
              <Link
                href="/category/seating"
                className="text-white/80 hover:text-white text-xs font-medium px-4 py-2 transition-colors duration-200 uppercase tracking-wide"
              >
                Seating
              </Link>
              <Link
                href="/category/tables"
                className="text-white/80 hover:text-white text-xs font-medium px-4 py-2 transition-colors duration-200 uppercase tracking-wide"
              >
                Tables
              </Link>
              <Link
                href="/category/lighting"
                className="text-white/80 hover:text-white text-xs font-medium px-4 py-2 transition-colors duration-200 uppercase tracking-wide"
              >
                Lighting
              </Link>
              <Link
                href="/about"
                className="text-white/80 hover:text-white text-xs font-medium px-4 py-2 transition-colors duration-200 uppercase tracking-wide"
              >
                About
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              {/* Desktop Search */}
              <div className="hidden md:block">
                <SearchBar />
              </div>

              {/* Mobile Search Toggle */}
              <button
                className="md:hidden text-white/80 hover:text-white transition-colors duration-200"
                onClick={() => setShowSearch(!showSearch)}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </button>

              <CartIcon />
            </div>
          </div>

          {/* Mobile Search Bar */}
          {showSearch && (
            <div className="md:hidden pb-4">
              <SearchBar />
            </div>
          )}
        </div>
      </header>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-80 bg-black/90 backdrop-blur-md border-l border-white/10 p-6">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-white text-lg font-light">Menu</h2>
              <button className="text-white p-2" onClick={() => setIsMobileMenuOpen(false)}>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <nav className="space-y-6">
              <Link
                href="/category/new"
                className="block text-white text-lg font-light hover:text-white/80 transition-colors duration-200"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                New Arrivals
              </Link>
              <Link
                href="/category/seating"
                className="block text-white text-lg font-light hover:text-white/80 transition-colors duration-200"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Seating
              </Link>
              <Link
                href="/category/tables"
                className="block text-white text-lg font-light hover:text-white/80 transition-colors duration-200"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Tables
              </Link>
              <Link
                href="/category/lighting"
                className="block text-white text-lg font-light hover:text-white/80 transition-colors duration-200"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Lighting
              </Link>
              <Link
                href="/about"
                className="block text-white text-lg font-light hover:text-white/80 transition-colors duration-200"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About
              </Link>
              <Link
                href="/search"
                className="block text-white text-lg font-light hover:text-white/80 transition-colors duration-200"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Search
              </Link>
              <Link
                href="/cart"
                className="block text-white text-lg font-light hover:text-white/80 transition-colors duration-200"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Cart
              </Link>
            </nav>

            <div className="mt-12 pt-6 border-t border-white/10">
              {/* Updated Tagline */}
              <p className="text-white/60 text-sm italic instrument">Premium. Minimal. Luminous.</p>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
