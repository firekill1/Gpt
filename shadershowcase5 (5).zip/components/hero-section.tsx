"use client"

import Image from "next/image"

export default function HeroSection() {
  return (
    <section className="relative mb-12 lg:mb-16 animate-fade-in">
      <div className="relative h-[70vh] lg:h-[80vh] rounded-xl overflow-hidden group">
        <Image
          src="/modern-minimalist-furniture-hero-image.jpg"
          alt="Featured Modern Minimalist Furniture"
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

        {/* Product Label - Top Left */}
        <div className="absolute top-6 left-6 backdrop-blur-md bg-white/10 border border-white/20 rounded-lg px-4 py-2">
          <p className="text-white text-sm font-medium tracking-wide">FEATURED</p>
        </div>

        {/* Product Info - Bottom Left */}
        <div className="absolute bottom-6 left-6 text-white">
          <h1 className="text-3xl lg:text-5xl font-light mb-2 tracking-tight">Refined. Minimal.</h1>
          <p className="text-lg lg:text-xl font-light mb-4 italic instrument">Never boring.</p>
          <p className="text-sm lg:text-base text-white/80 max-w-md leading-relaxed">
            Furniture that speaks softly, but stands out loud. Clean lines, crafted with wit.
          </p>
        </div>

        {/* Price Tag - Bottom Right */}
        <div className="absolute bottom-6 right-6 backdrop-blur-md bg-white/10 border border-white/20 rounded-lg px-4 py-2">
          <p className="text-white text-lg font-medium">$2,499</p>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.6s ease-out;
        }
      `}</style>
    </section>
  )
}
