"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Sidebar() {
  return (
    <aside className="sticky top-24 h-fit animate-slide-in-left" style={{ animationDelay: "0.2s" }}>
      <div className="backdrop-blur-md bg-white/5 border border-white/10 rounded-xl p-6">
        {/* Brand Message */}
        <div className="mb-8">
          <h2 className="text-2xl font-light text-white mb-3 tracking-tight">Elegance with a wink</h2>
          <p className="text-white/70 text-sm leading-relaxed italic instrument">Style first</p>
        </div>

        <div className="mb-8">
          <Link href="/search">
            <Button
              variant="outline"
              className="w-full border-white/20 text-white hover:bg-white hover:text-black bg-transparent"
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
              Search Products
            </Button>
          </Link>
        </div>

        {/* Navigation Links */}
        <nav className="space-y-4">
          <Link
            href="/category/new"
            className="block text-white/80 hover:text-white transition-colors duration-200 text-sm tracking-wide uppercase"
          >
            New Arrivals
          </Link>
          <Link
            href="/category/seating"
            className="block text-white/80 hover:text-white transition-colors duration-200 text-sm tracking-wide uppercase"
          >
            Seating
          </Link>
          <Link
            href="/category/tables"
            className="block text-white/80 hover:text-white transition-colors duration-200 text-sm tracking-wide uppercase"
          >
            Tables
          </Link>
          <Link
            href="/category/lighting"
            className="block text-white/80 hover:text-white transition-colors duration-200 text-sm tracking-wide uppercase"
          >
            Lighting
          </Link>
          <Link
            href="/category/all"
            className="block text-white/80 hover:text-white transition-colors duration-200 text-sm tracking-wide uppercase"
          >
            All Products
          </Link>
        </nav>

        <div className="mt-8 pt-6 border-t border-white/10">
          <h3 className="text-white text-sm font-medium mb-3 tracking-wide uppercase">Quick Filters</h3>
          <div className="space-y-2">
            <Link
              href="/search?sort=price-low"
              className="block text-white/60 hover:text-white text-xs transition-colors"
            >
              Price: Low to High
            </Link>
            <Link
              href="/search?sort=price-high"
              className="block text-white/60 hover:text-white text-xs transition-colors"
            >
              Price: High to Low
            </Link>
            <Link href="/search?sort=rating" className="block text-white/60 hover:text-white text-xs transition-colors">
              Highest Rated
            </Link>
            <Link
              href="/search?category=new"
              className="block text-white/60 hover:text-white text-xs transition-colors"
            >
              New Arrivals Only
            </Link>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes slide-in-left {
          from { opacity: 0; transform: translateX(-20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .animate-slide-in-left {
          animation: slide-in-left 0.6s ease-out both;
        }
      `}</style>
    </aside>
  )
}
