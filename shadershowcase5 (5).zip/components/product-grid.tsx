"use client"

import Image from "next/image"
import Link from "next/link"
import { products } from "@/lib/products"

export default function ProductGrid() {
  return (
    <section className="mb-16">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {products.map((product, index) => (
          <div
            key={product.id}
            className="relative group cursor-pointer animate-fade-in-up hover:-translate-y-1 transition-transform duration-300"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <Link href={`/product/${product.id}`}>
              <div className="relative aspect-square rounded-lg overflow-hidden">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />

                {product.label && (
                  <div
                    className={`absolute ${
                      product.labelPosition === "top-left"
                        ? "top-4 left-4"
                        : product.labelPosition === "top-right"
                          ? "top-4 right-4"
                          : product.labelPosition === "bottom-left"
                            ? "bottom-4 left-4"
                            : "bottom-4 right-4"
                    } backdrop-blur-md bg-white/10 border border-white/20 rounded-lg px-3 py-1`}
                  >
                    <p className="text-white text-xs font-medium tracking-wide">{product.label}</p>
                  </div>
                )}

                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

              {/* Product Info */}
              <div className="mt-4 text-white">
                <h3 className="text-lg font-medium tracking-tight">{product.name}</h3>
                <p className="text-white/80 text-sm mt-1">${product.price}</p>
              </div>
            </Link>
          </div>
        ))}
      </div>

      <style jsx>{`
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.6s ease-out both;
        }
      `}</style>
    </section>
  )
}
