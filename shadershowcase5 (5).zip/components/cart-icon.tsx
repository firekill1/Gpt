"use client"

import { Button } from "@/components/ui/button"
import { useCart } from "@/contexts/cart-context"
import Link from "next/link"

export default function CartIcon() {
  const { state } = useCart()

  return (
    <Link href="/cart">
      <Button variant="ghost" size="sm" className="relative text-white hover:bg-white/10">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5 6m0 0h9M17 21a2 2 0 100-4 2 2 0 000 4zM9 21a2 2 0 100-4 2 2 0 000 4z"
          />
        </svg>
        {state.itemCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-white text-black text-xs rounded-full w-5 h-5 flex items-center justify-center font-medium">
            {state.itemCount > 9 ? "9+" : state.itemCount}
          </span>
        )}
      </Button>
    </Link>
  )
}
