// Cart functionality for LumeoShop Shopify theme

class CartManager {
  constructor() {
    this.cart = null
    this.isUpdating = false
    this.init()
  }

  init() {
    this.bindEvents()
    this.updateCartCount()
  }

  bindEvents() {
    // Add to cart forms
    document.addEventListener("submit", (e) => {
      if (e.target.matches('[data-type="add-to-cart-form"]')) {
        e.preventDefault()
        this.handleAddToCart(e.target)
      }
    })

    // Cart quantity changes
    document.addEventListener("change", (e) => {
      if (e.target.matches('[name="updates[]"]')) {
        this.handleQuantityChange(e.target)
      }
    })

    // Remove from cart
    document.addEventListener("click", (e) => {
      if (e.target.matches("[data-cart-remove]")) {
        e.preventDefault()
        this.handleRemoveFromCart(e.target)
      }
    })

    // Cart drawer toggle
    document.addEventListener("click", (e) => {
      if (e.target.matches("[data-cart-toggle]")) {
        e.preventDefault()
        this.toggleCartDrawer()
      }
    })
  }

  async handleAddToCart(form) {
    if (this.isUpdating) return

    this.isUpdating = true
    const formData = new FormData(form)
    const submitButton = form.querySelector('[type="submit"]')

    // Show loading state
    if (submitButton) {
      submitButton.disabled = true
      submitButton.textContent = "Adding..."
    }

    try {
      const response = await fetch("/cart/add.js", {
        method: "POST",
        body: formData,
      })

      if (response.ok) {
        await this.updateCartCount()
        this.showCartNotification("Item added to cart")
        this.openCartDrawer()
      } else {
        throw new Error("Failed to add item to cart")
      }
    } catch (error) {
      console.error("Add to cart error:", error)
      this.showCartNotification("Error adding item to cart", "error")
    } finally {
      this.isUpdating = false
      if (submitButton) {
        submitButton.disabled = false
        submitButton.textContent = "Add to Cart"
      }
    }
  }

  async handleQuantityChange(input) {
    if (this.isUpdating) return

    this.isUpdating = true
    const formData = new FormData()
    formData.append("updates[]", input.value)
    formData.append("id", input.dataset.lineId)

    try {
      const response = await fetch("/cart/update.js", {
        method: "POST",
        body: formData,
      })

      if (response.ok) {
        await this.updateCartCount()
        this.refreshCartDrawer()
      }
    } catch (error) {
      console.error("Update cart error:", error)
    } finally {
      this.isUpdating = false
    }
  }

  async handleRemoveFromCart(button) {
    if (this.isUpdating) return

    this.isUpdating = true
    const lineId = button.dataset.lineId

    try {
      const response = await fetch("/cart/change.js", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: lineId,
          quantity: 0,
        }),
      })

      if (response.ok) {
        await this.updateCartCount()
        this.refreshCartDrawer()
      }
    } catch (error) {
      console.error("Remove from cart error:", error)
    } finally {
      this.isUpdating = false
    }
  }

  async updateCartCount() {
    try {
      const response = await fetch("/cart.js")
      this.cart = await response.json()

      const cartCountElements = document.querySelectorAll("[data-cart-count]")
      cartCountElements.forEach((element) => {
        element.textContent = this.cart.item_count
      })
    } catch (error) {
      console.error("Update cart count error:", error)
    }
  }

  toggleCartDrawer() {
    const drawer = document.querySelector("[data-cart-drawer]")
    if (drawer) {
      drawer.classList.toggle("open")
    }
  }

  openCartDrawer() {
    const drawer = document.querySelector("[data-cart-drawer]")
    if (drawer) {
      drawer.classList.add("open")
    }
  }

  refreshCartDrawer() {
    // Refresh cart drawer content
    const drawer = document.querySelector("[data-cart-drawer]")
    if (drawer && drawer.classList.contains("open")) {
      // Reload cart drawer content via AJAX
      fetch("/cart?view=drawer")
        .then((response) => response.text())
        .then((html) => {
          const parser = new DOMParser()
          const doc = parser.parseFromString(html, "text/html")
          const newContent = doc.querySelector("[data-cart-drawer-content]")
          const currentContent = drawer.querySelector("[data-cart-drawer-content]")
          if (newContent && currentContent) {
            currentContent.innerHTML = newContent.innerHTML
          }
        })
    }
  }

  showCartNotification(message, type = "success") {
    const notification = document.createElement("div")
    notification.className = `cart-notification cart-notification--${type}`
    notification.textContent = message

    document.body.appendChild(notification)

    setTimeout(() => {
      notification.classList.add("show")
    }, 100)

    setTimeout(() => {
      notification.classList.remove("show")
      setTimeout(() => {
        document.body.removeChild(notification)
      }, 300)
    }, 3000)
  }
}

// Initialize cart manager when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  new CartManager()
})
