window.theme = window.theme || {}

// Theme constants
window.theme.strings = {
  addToCart: "Add to cart",
  soldOut: "Sold out",
  unavailable: "Unavailable",
  regularPrice: "Regular price",
  salePrice: "Sale price",
  unitPrice: "Unit price",
  unitPriceSeparator: "per",
  onlyXLeft: "Only {{ count }} left!",
  quantityMinimumMessage: "Quantity must be 1 or more",
  quantityMaximumMessage: "You can only add {{ quantity }} of this item to your cart",
  cartError: "There was an error while updating your cart. Please try again.",
  cartTermsConfirmation: "You must agree with the terms and conditions of sales to check out",
  searchCollections: "Collections",
  searchPages: "Pages",
  searchArticles: "Articles",
}

// Breakpoints
window.theme.breakpoints = {
  medium: 750,
  large: 990,
  widescreen: 1400,
}

// Animation settings
window.theme.settings = {
  cartType: "drawer",
  isCustomerTemplate: false,
  moneyFormat: "${{amount}}",
  predictiveSearch: true,
}
