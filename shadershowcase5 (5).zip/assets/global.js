// Global JavaScript for LumeoShop Shopify theme

class ThemeGlobal {
  constructor() {
    this.init()
  }

  init() {
    this.initMobileMenu()
    this.initSearch()
    this.initStickyHeader()
    this.initAnimations()
    this.initAccessibility()
  }

  // Mobile menu functionality
  initMobileMenu() {
    const mobileMenuButton = document.querySelector(".header__mobile-menu-button")
    const mobileMenuOverlay = document.querySelector(".mobile-menu-overlay")
    const mobileMenuDrawer = document.querySelector(".mobile-menu-drawer")
    const mobileMenuClose = document.querySelector(".mobile-menu-close")

    if (!mobileMenuButton || !mobileMenuOverlay || !mobileMenuDrawer) return

    const openMobileMenu = () => {
      mobileMenuOverlay.classList.add("active")
      mobileMenuDrawer.classList.add("active")
      document.body.style.overflow = "hidden"

      // Focus management
      const firstFocusable = mobileMenuDrawer.querySelector("a, button")
      if (firstFocusable) firstFocusable.focus()
    }

    const closeMobileMenu = () => {
      mobileMenuOverlay.classList.remove("active")
      mobileMenuDrawer.classList.remove("active")
      document.body.style.overflow = ""
      mobileMenuButton.focus()
    }

    mobileMenuButton.addEventListener("click", openMobileMenu)
    mobileMenuClose?.addEventListener("click", closeMobileMenu)
    mobileMenuOverlay.addEventListener("click", closeMobileMenu)

    // Close on escape key
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && mobileMenuDrawer.classList.contains("active")) {
        closeMobileMenu()
      }
    })

    // Close menu when clicking on menu links
    const menuLinks = mobileMenuDrawer.querySelectorAll("a")
    menuLinks.forEach((link) => {
      link.addEventListener("click", closeMobileMenu)
    })
  }

  // Search modal functionality
  initSearch() {
    const searchButtons = document.querySelectorAll("[data-search-toggle]")
    const searchModal = document.querySelector(".search-modal")
    const searchClose = document.querySelector(".search-modal__close-button")
    const searchInput = document.querySelector(".search__input")

    if (!searchModal) return

    const openSearch = () => {
      searchModal.classList.add("active")
      document.body.style.overflow = "hidden"

      // Focus on search input
      setTimeout(() => {
        if (searchInput) searchInput.focus()
      }, 100)
    }

    const closeSearch = () => {
      searchModal.classList.remove("active")
      document.body.style.overflow = ""
    }

    searchButtons.forEach((button) => {
      button.addEventListener("click", openSearch)
    })

    searchClose?.addEventListener("click", closeSearch)
    searchModal.addEventListener("click", (e) => {
      if (e.target === searchModal) closeSearch()
    })

    // Close on escape key
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && searchModal.classList.contains("active")) {
        closeSearch()
      }
    })
  }

  // Sticky header functionality
  initStickyHeader() {
    const stickyHeader = document.querySelector("sticky-header")
    if (!stickyHeader) return

    const stickyType = stickyHeader.dataset.stickyType
    if (stickyType === "never") return

    let lastScrollY = window.scrollY
    let ticking = false

    const updateHeader = () => {
      const currentScrollY = window.scrollY

      if (stickyType === "always") {
        stickyHeader.classList.toggle("scrolled", currentScrollY > 0)
      } else if (stickyType === "on-scroll-up") {
        if (currentScrollY > 100) {
          if (currentScrollY < lastScrollY) {
            stickyHeader.classList.add("scrolled-up")
          } else {
            stickyHeader.classList.remove("scrolled-up")
          }
        } else {
          stickyHeader.classList.remove("scrolled-up")
        }
      }

      lastScrollY = currentScrollY
      ticking = false
    }

    const requestTick = () => {
      if (!ticking) {
        requestAnimationFrame(updateHeader)
        ticking = true
      }
    }

    window.addEventListener("scroll", requestTick, { passive: true })
  }

  // Animation on scroll
  initAnimations() {
    const animatedElements = document.querySelectorAll("[data-animate]")
    if (!animatedElements.length) return

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const element = entry.target
            const animationType = element.dataset.animate
            const delay = element.dataset.animateDelay || 0

            setTimeout(() => {
              element.classList.add(`animate-${animationType}`)
            }, delay)

            observer.unobserve(element)
          }
        })
      },
      {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px",
      },
    )

    animatedElements.forEach((element) => {
      observer.observe(element)
    })
  }

  // Accessibility improvements
  initAccessibility() {
    // Skip to content link
    const skipLink = document.querySelector(".skip-to-content-link")
    const mainContent = document.querySelector("#MainContent")

    if (skipLink && mainContent) {
      skipLink.addEventListener("click", (e) => {
        e.preventDefault()
        mainContent.focus()
        mainContent.scrollIntoView()
      })
    }

    // Improve focus visibility
    document.addEventListener("keydown", (e) => {
      if (e.key === "Tab") {
        document.body.classList.add("using-keyboard")
      }
    })

    document.addEventListener("mousedown", () => {
      document.body.classList.remove("using-keyboard")
    })

    // Announce dynamic content changes
    this.createLiveRegion()
  }

  // Create live region for screen readers
  createLiveRegion() {
    const liveRegion = document.createElement("div")
    liveRegion.setAttribute("aria-live", "polite")
    liveRegion.setAttribute("aria-atomic", "true")
    liveRegion.className = "visually-hidden"
    liveRegion.id = "live-region"
    document.body.appendChild(liveRegion)

    // Utility function to announce messages
    window.announceToScreenReader = (message) => {
      const liveRegion = document.getElementById("live-region")
      if (liveRegion) {
        liveRegion.textContent = message
        setTimeout(() => {
          liveRegion.textContent = ""
        }, 1000)
      }
    }
  }
}

// Utility functions
window.ThemeUtils = {
  // Debounce function
  debounce(func, wait, immediate) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        timeout = null
        if (!immediate) func(...args)
      }
      const callNow = immediate && !timeout
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
      if (callNow) func(...args)
    }
  },

  // Throttle function
  throttle(func, limit) {
    let inThrottle
    return function (...args) {
      if (!inThrottle) {
        func.apply(this, args)
        inThrottle = true
        setTimeout(() => (inThrottle = false), limit)
      }
    }
  },

  // Format money
  formatMoney(cents, format) {
    if (typeof cents === "string") {
      cents = cents.replace(".", "")
    }

    const value = ""
    const placeholderRegex = /\{\{\s*(\w+)\s*\}\}/
    const formatString = format || "${{amount}}"

    function formatWithDelimiters(number, precision, thousands, decimal) {
      thousands = thousands || ","
      decimal = decimal || "."

      if (isNaN(number) || number === null) {
        return 0
      }

      number = (number / 100.0).toFixed(precision)

      const parts = number.split(".")
      const dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + thousands)
      const centsAmount = parts[1] ? decimal + parts[1] : ""

      return dollarsAmount + centsAmount
    }

    switch (formatString.match(placeholderRegex)[1]) {
      case "amount":
        value = formatWithDelimiters(cents, 2)
        break
      case "amount_no_decimals":
        value = formatWithDelimiters(cents, 0)
        break
      case "amount_with_comma_separator":
        value = formatWithDelimiters(cents, 2, ".", ",")
        break
      case "amount_no_decimals_with_comma_separator":
        value = formatWithDelimiters(cents, 0, ".", ",")
        break
      case "amount_no_decimals_with_space_separator":
        value = formatWithDelimiters(cents, 0, " ")
        break
      case "amount_with_apostrophe_separator":
        value = formatWithDelimiters(cents, 2, "'")
        break
    }

    return formatString.replace(placeholderRegex, value)
  },

  // Get URL parameters
  getUrlParameter(name) {
    name = name.replace(/[[]/, "\\[").replace(/[\]]/, "\\]")
    const regex = new RegExp("[\\?&]" + name + "=([^&#]*)")
    const results = regex.exec(location.search)
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "))
  },

  // Cookie utilities
  setCookie(name, value, days) {
    let expires = ""
    if (days) {
      const date = new Date()
      date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000)
      expires = "; expires=" + date.toUTCString()
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/"
  },

  getCookie(name) {
    const nameEQ = name + "="
    const ca = document.cookie.split(";")
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i]
      while (c.charAt(0) === " ") c = c.substring(1, c.length)
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
    }
    return null
  },

  eraseCookie(name) {
    document.cookie = name + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;"
  },
}

// Initialize theme when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  new ThemeGlobal()
})

// Handle page visibility changes
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    // Page became visible, refresh any time-sensitive content
    const event = new CustomEvent("page:visible")
    document.dispatchEvent(event)
  }
})

// Handle resize events
window.addEventListener(
  "resize",
  ThemeUtils.debounce(() => {
    const event = new CustomEvent("theme:resize")
    document.dispatchEvent(event)
  }, 250),
)

// Export for use in other scripts
window.ThemeGlobal = ThemeGlobal
