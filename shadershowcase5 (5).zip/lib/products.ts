export interface Product {
  id: number
  name: string
  price: number
  originalPrice: number
  image: string
  images: string[]
  description: string
  features: string[]
  rating: number
  reviews: number
  inStock: boolean
  category: string
  label?: string
  labelPosition?: string
}

export const products: Product[] = [
  {
    id: 1,
    name: "Minimal Chair",
    price: 899,
    originalPrice: 1099,
    image: "/modern-minimal-chair-design.jpg",
    images: [
      "/modern-minimal-chair-design.jpg",
      "/minimal-chair-side-view.jpg",
      "/minimal-chair-back-view.jpg",
      "/minimal-chair-detail-view.jpg",
    ],
    description:
      "A masterpiece of minimalist design, this chair combines comfort with architectural precision. Crafted from premium materials with attention to every detail.",
    features: ["Premium oak wood frame", "Ergonomic design", "Sustainable materials", "Handcrafted finish"],
    rating: 4.8,
    reviews: 124,
    inStock: true,
    category: "Seating",
    label: "NEW",
    labelPosition: "top-left",
  },
  {
    id: 2,
    name: "Elegant Table",
    price: 1299,
    originalPrice: 1599,
    image: "/elegant-minimalist-dining-table.jpg",
    images: [
      "/elegant-minimalist-dining-table.jpg",
      "/elegant-dining-table-top-view.jpg",
      "/elegant-dining-table-side-view.jpg",
      "/elegant-dining-table-detail-view.jpg",
    ],
    description:
      "An elegant dining table that serves as the centerpiece of modern living. Clean lines meet functional beauty in this timeless design.",
    features: ["Solid walnut construction", "Seats 6 comfortably", "Water-resistant finish", "Easy assembly"],
    rating: 4.9,
    reviews: 89,
    inStock: true,
    category: "Tables",
    label: "POPULAR",
    labelPosition: "top-right",
  },
  {
    id: 3,
    name: "Refined Sofa",
    price: 2199,
    originalPrice: 2799,
    image: "/refined-modern-sofa-minimalist.jpg",
    images: [
      "/refined-modern-sofa-minimalist.jpg",
      "/refined-sofa-side-view.jpg",
      "/refined-sofa-back-view.jpg",
      "/refined-sofa-detail-view.jpg",
    ],
    description:
      "Luxury meets comfort in this refined sofa. Perfect for modern living spaces that demand both style and functionality.",
    features: ["Premium fabric upholstery", "Hardwood frame", "High-density foam", "Removable cushions"],
    rating: 4.7,
    reviews: 156,
    inStock: true,
    category: "Seating",
    label: "SALE",
    labelPosition: "bottom-left",
  },
  {
    id: 4,
    name: "Statement Lamp",
    price: 449,
    originalPrice: 599,
    image: "/statement-modern-lamp-design.jpg",
    images: [
      "/statement-modern-lamp-design.jpg",
      "/statement-lamp-side-view.jpg",
      "/statement-lamp-detail-view.jpg",
      "/statement-lamp-lighting-effect.jpg",
    ],
    description:
      "A sculptural lighting piece that transforms any space. This statement lamp combines artistic form with practical illumination.",
    features: ["LED technology", "Dimmable lighting", "Brass finish", "Touch controls"],
    rating: 4.6,
    reviews: 73,
    inStock: true,
    category: "Lighting",
    label: "LIMITED",
    labelPosition: "bottom-right",
  },
]

export const categories = [
  { id: "all", name: "All Products", count: products.length },
  { id: "new", name: "New Arrivals", count: products.filter((p) => p.label === "NEW").length },
  { id: "seating", name: "Seating", count: products.filter((p) => p.category === "Seating").length },
  { id: "tables", name: "Tables", count: products.filter((p) => p.category === "Tables").length },
  { id: "lighting", name: "Lighting", count: products.filter((p) => p.category === "Lighting").length },
]
